import javax.swing.*;
import java.awt.*;
import java.util.*;

import GUIComponents.*;

class Main{
    public static void main(String args[]){
    	
    	/*
       JFrame frame = new JFrame("My First GUI");
       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       frame.setSize(300,300);
       JButton button = new JButton("Press");
       frame.getContentPane().add(button); // Adds Button to content pane of frame
       frame.setVisible(true);
       
       JFrame frame2 = new JFrame("My Second GUI");
       frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       frame2.setSize(300,300);
       JButton button2 = new JButton("Press2");
       frame2.getContentPane().add(button2); // Adds Button to content pane of frame
       frame2.setVisible(true);
       */
    	
    	JFrame telefonKonyv = new JFrame("TelefonK�nyv");
    	telefonKonyv.setSize(800,800);
    	telefonKonyv.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	JMenuBar telefonKonyvMenu = new JMenuBar();
    	
    	
    	JMenu fileMenu = new JMenu("File");
    	JMenuItem importMenuItem = new JMenu("Import");
    	JMenuItem exportMenuItem = new JMenu("Export");
    	JMenuItem exitMenuItem = new JMenu("Exit");
    	fileMenu.add(importMenuItem);
    	fileMenu.add(exportMenuItem);
    	fileMenu.add(exitMenuItem);
    	
    	JMenu helpMenu = new JMenu("Seg�ts�g");
    
    	telefonKonyvMenu.add(fileMenu);
    	telefonKonyvMenu.add(helpMenu);
    	
    	JPanel footerPanel = new JPanel();
    	JLabel searchLabel = new JLabel("Search");
    	JTextField searchField = new JTextField(20);
    	ExcecutionButton searchButton = new ExcecutionButton();
    	footerPanel.add(searchLabel);
    	footerPanel.add(searchField);
    	footerPanel.add(searchButton);
    	
    	DetailedPanel detailedPanel = new DetailedPanel();
    	String sampleStrings[] = {"Hai Anh", "Nam", "Long", "Khoi", "Huong"};
    	ArrayList<String> names = new ArrayList<String>( Arrays.asList("Hai Anh", "Nam", "Long", "Khoi", "Huong"));
    	for (int i = 0; i < 100; i++) {
    		names.add("Duy");
    	}
    	
    	JList samplejList = new JList(names.toArray());
    	JScrollPane sampleScroll = new JScrollPane(samplejList);
    	JSplitPane bodyPanel = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, sampleScroll, detailedPanel);
    	bodyPanel.setOneTouchExpandable(true);
    	bodyPanel.setDividerLocation(400);
    	Dimension minimumSize = new Dimension(100, 100);
    	sampleScroll.setMinimumSize(minimumSize);
    	detailedPanel.setMinimumSize(minimumSize);
    	
    	telefonKonyv.getContentPane().add(BorderLayout.NORTH, telefonKonyvMenu);
    	telefonKonyv.getContentPane().add(BorderLayout.SOUTH, footerPanel);
    	telefonKonyv.getContentPane().add(BorderLayout.CENTER, bodyPanel);
    	
    	telefonKonyv.setVisible(true);
    }
}