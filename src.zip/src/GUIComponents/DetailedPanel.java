package GUIComponents;

import java.awt.*;
import java.util.ArrayList;

import javax.swing.*;


public class DetailedPanel extends JPanel {
	ArrayList<JLabel> jlabels = new ArrayList<JLabel>();
	ArrayList<JTextField> jTextField = new ArrayList<JTextField>();
	String[] labels = {"Name:", "Email:", "Phone:"};
	ArrayList<JTextField> extraPhoneNumbers = new ArrayList<JTextField>();
	
	public void
	
	public DetailedPanel() {
		super(new BorderLayout());
		SpringLayout layout = new SpringLayout();
		JPanel content = new JPanel(layout);
		
		AddPhoneNumberButton addingPhoneButton = new AddPhoneNumberButton();
		content.add(addingPhoneButton);
		layout.putConstraint(SpringLayout.SOUTH, content,5, SpringLayout.SOUTH, addingPhoneButton);
		
		
		
		for(int i = 0; i < labels.length; i++) {
			JLabel label = new JLabel(labels[i]);
			JTextField textField = new JTextField("", 20);
			jlabels.add(label);
			jTextField.add(textField);
			
			content.add(label);
			content.add(textField);
			layout.putConstraint(SpringLayout.WEST, label,5, SpringLayout.WEST, content);
			layout.putConstraint(SpringLayout.WEST, textField, 50, SpringLayout.WEST, content);
			//layout.putConstraint(SpringLayout.EAST, content,5, SpringLayout.EAST, textField);
			
			if (i == 0) {
			    layout.putConstraint(SpringLayout.NORTH, label,5, SpringLayout.NORTH, content);
			    layout.putConstraint(SpringLayout.NORTH, textField,5, SpringLayout.NORTH, content);
			} else {
				layout.putConstraint(SpringLayout.NORTH, label,5, SpringLayout.SOUTH, jTextField.get(i-1));
			    layout.putConstraint(SpringLayout.NORTH, textField,5, SpringLayout.SOUTH, jTextField.get(i-1));
			}
			
			
			if (i == labels.length - 1) {
			    layout.putConstraint(SpringLayout.NORTH, addingPhoneButton,5, SpringLayout.SOUTH, textField);
			}
			
		}
		
		
		JButton saveButton = new JButton("Save");
		this.add(BorderLayout.NORTH, content);
		this.add(BorderLayout.SOUTH ,saveButton);
	}
	
	
}
