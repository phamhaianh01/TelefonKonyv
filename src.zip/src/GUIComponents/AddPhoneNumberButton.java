package GUIComponents;

import java.awt.event.*;

import javax.swing.*;

public class AddPhoneNumberButton extends JButton {
	ActionListener al = new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("Added");
		}
		
	};
	
	public AddPhoneNumberButton() {
		super("Add Phone Number");
		this.addActionListener(al);
	}

}
