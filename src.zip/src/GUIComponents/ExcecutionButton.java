package GUIComponents;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;


public class ExcecutionButton extends JButton {
	ActionListener al = new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			System.out.println("Excecuted");
		}
	};
	
	
	public ExcecutionButton() {
		super("Excecute");
		this.addActionListener(al);
	}
	
	
}
